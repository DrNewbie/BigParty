function ElementSpecialObjective:nav_link_delay()
	return 0.1
end