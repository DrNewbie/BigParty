if Announcer then
	Announcer:AddHostMod('Spawn More and Faster, (http://modwork.shop/20649)')
end

if UpdateThisMod then
	UpdateThisMod:Add({
		mod_id = 'Spawn More and Faster',
		data = {
			modworkshop_id = "BigParty_20649",
			dl_url = 'https://drnewbie.github.io/BigParty/Spawn%20More%20and%20Faster.zip',
			info_url = 'https://drnewbie.github.io/BigParty/Spawn%20More%20and%20Faster/mod.txt'
		}
	})
end