function ElementSpecialObjective:clbk_objective_administered(unit)
	return
end

function ElementSpecialObjective:clbk_verify_administration(unit)
	return true
end

function ElementSpecialObjective:nav_link_delay()
	return 0.1
end